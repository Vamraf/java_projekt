public class Potion extends Item {

    private int restoreAmount;

    public Potion(String name, int value, int restoreAmount) {
        super(name, ItemType.POTION, value);
        this.restoreAmount = restoreAmount;
    }

    public int getRestoreAmount() {
        return restoreAmount;
    }

    @Override
    public String toString() {
        return super.toString() + ", restore=" + restoreAmount;
    }
}
