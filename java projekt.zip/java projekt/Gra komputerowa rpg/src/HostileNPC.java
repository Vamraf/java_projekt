public class HostileNPC extends NonPlayerCharacter {
    private int attackPower;
    private int aggressionLevel; // 1–10
    private String battleCry;

    public HostileNPC(String name, int level, int healthPoints, int mana,
                      String npcType, int attackPower, int aggressionLevel,
                      String battleCry) {
        super(name, level, healthPoints, mana, npcType);
        this.attackPower = attackPower;
        this.aggressionLevel = aggressionLevel;
        this.battleCry = battleCry;
    }

    @Override
    public void attack() {
        System.out.println(name + " (" + npcType + ") attacks fiercely! Power: " + attackPower);
    }

    @Override
    public void defend() {
        System.out.println(name + " (" + npcType + ") braces for impact!");
    }

    public void speak() {
        System.out.println(name + " roars: \"" + battleCry + "\"");
    }

    @Override
    public String toString() {
        return super.toString() +
                ", attackPower=" + attackPower +
                ", aggressionLevel=" + aggressionLevel +
                ", battleCry='" + battleCry + "'";
    }
}
