public class MagicItem extends Item {

    private String effect;

    public MagicItem(String name, int value, String effect) {
        super(name, ItemType.MAGIC, value);
        this.effect = effect;
    }

    public String getEffect() {
        return effect;
    }

    @Override
    public String toString() {
        return super.toString() + ", effect='" + effect + "'";
    }
}
