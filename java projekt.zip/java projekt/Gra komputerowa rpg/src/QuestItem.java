public class QuestItem extends Item {

    private String questName;

    public QuestItem(String name, int value, String questName) {
        super(name, ItemType.QUEST, value);
        this.questName = questName;
    }

    public String getQuestName() {
        return questName;
    }

    @Override
    public String toString() {
        return super.toString() + ", quest='" + questName + "'";
    }
}
