public class MiscItem extends Item {

    public MiscItem(String name, int value) {
        super(name, ItemType.MISC, value);
    }

    @Override
    public String toString() {
        return super.toString() + " (misc)";
    }
}
