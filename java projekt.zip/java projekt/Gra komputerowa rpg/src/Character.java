public abstract class Character {

    // --- Static field ---
    public static int characterCount = 0;

    // --- Fields ---
    protected String name;
    protected int level;
    protected int healthPoints;
    protected int mana;

    // --- Constructor ---
    public Character(String name, int level, int healthPoints, int mana) {
        this.name = name;
        this.level = level;
        this.healthPoints = healthPoints;
        this.mana = mana;

        characterCount++;
    }

    // --- Abstract methods ---
    public abstract void attack();
    public abstract void defend();

    // --- Static method ---
    public static void showGlobalStats() {
        System.out.println("Total characters created: " + characterCount);
    }

    // --- toString ---
    @Override
    public String toString() {
        return getClass().getSimpleName() + "{name='" + name + '\'' +
                ", level=" + level +
                ", healthPoints=" + healthPoints +
                ", mana=" + mana + '}';
    }

    // --- equals ---
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Character other = (Character) obj;
        return level == other.level &&
                healthPoints == other.healthPoints &&
                mana == other.mana &&
                name.equals(other.name);
    }

    // --- hashCode ---
    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + level;
        result = 31 * result + healthPoints;
        result = 31 * result + mana;
        return result;
    }

    // --- GETTERS for convenience ---
    public String getName() { return name; }
    public int getLevel() { return level; }
    public int getHealthPoints() { return healthPoints; }
    public int getMana() { return mana; }


}
