public class Archer extends PlayerCharacter {

    private int arrowCount;
    private int agility;

    public Archer(String name, int level, int healthPoints, int mana, int arrowCount, int agility) {
        super(name, level, healthPoints, mana);
        this.arrowCount = arrowCount;
        this.agility = agility;
    }

    @Override
    public void attack() {
        if (arrowCount > 0) {
            System.out.println(name + " shoots an arrow! (" + arrowCount + " left)");
            arrowCount--;
        } else {
            System.out.println(name + " has no arrows left!");
        }
    }

    @Override
    public void defend() {
        System.out.println(name + " dodges swiftly using agility!");
    }

    @Override
    public String toString() {
        return super.toString() +
                ", arrowCount=" + arrowCount +
                ", agility=" + agility;
    }
}
