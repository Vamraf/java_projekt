public class Weapon extends Item {

    private int damage;

    public Weapon(String name, int value, int damage) {
        super(name, ItemType.WEAPON, value);
        this.damage = damage;
    }

    public int getDamage() {
        return damage;
    }

    @Override
    public String toString() {
        return super.toString() + ", damage=" + damage;
    }
}
