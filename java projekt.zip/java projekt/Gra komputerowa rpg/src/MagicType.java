public enum MagicType {
    FIRE,
    ICE,
    WIND,
    EARTH
}
