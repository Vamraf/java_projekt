public enum ItemType {
    WEAPON,
    ARMOR,
    POTION,
    MAGIC,
    QUEST,
    MISC
}
