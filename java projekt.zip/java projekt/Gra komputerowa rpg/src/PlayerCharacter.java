public class PlayerCharacter extends Character {

    private int experience;
    private String[] inventory;

    public PlayerCharacter(String name, int level, int healthPoints, int mana) {
        super(name, level, healthPoints, mana);
        this.experience = 0;
        this.inventory = new String[10]; // простий інвентар
    }

    @Override
    public void attack() {
        System.out.println(name + " attacks with a weapon!");
    }

    @Override
    public void defend() {
        System.out.println(name + " blocks the incoming attack!");
    }

    public void addExperience(int xp) {
        experience += xp;
        if (experience >= 100) {
            level++;
            experience -= 100;
            System.out.println(name + " has leveled up! New level: " + level);
        }
    }

    @Override
    public String toString() {
        return super.toString() + ", XP=" + experience;
    }
}
