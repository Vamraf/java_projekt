public abstract class NonPlayerCharacter extends Character {

    protected String npcType;

    public NonPlayerCharacter(String name, int level, int healthPoints, int mana, String npcType) {
        super(name, level, healthPoints, mana);
        this.npcType = npcType;
    }

    public String getNpcType() {
        return npcType;
    }

    @Override
    public String toString() {
        return super.toString() + ", npcType=" + npcType;
    }
}
