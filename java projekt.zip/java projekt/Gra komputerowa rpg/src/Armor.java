public class Armor extends Item {

    private int defense;

    public Armor(String name, int value, int defense) {
        super(name, ItemType.ARMOR, value);
        this.defense = defense;
    }

    public int getDefense() {
        return defense;
    }

    @Override
    public String toString() {
        return super.toString() + ", defense=" + defense;
    }
}
