public class Warrior extends PlayerCharacter {

    private int strength;
    private int armor;

    public Warrior(String name, int level, int healthPoints, int mana, int strength, int armor) {
        super(name, level, healthPoints, mana);
        this.strength = strength;
        this.armor = armor;
    }

    @Override
    public void attack() {
        System.out.println(name + " performs a powerful sword slash! (STR: " + strength + ")");
    }

    @Override
    public void defend() {
        System.out.println(name + " blocks the attack with armor! (ARMOR: " + armor + ")");
    }

    @Override
    public String toString() {
        return super.toString() +
                ", strength=" + strength +
                ", armor=" + armor;
    }
}
