public class FriendlyNPC extends NonPlayerCharacter {

    private String dialogue;

    public FriendlyNPC(String name, int level, int healthPoints, int mana,
                       String npcType, String dialogue) {
        super(name, level, healthPoints, mana, npcType);
        this.dialogue = dialogue;
    }

    @Override
    public void attack() {
        System.out.println(name + " is friendly and will not attack.");
    }

    @Override
    public void defend() {
        System.out.println(name + " tries to avoid conflict peacefully.");
    }

    public void speak() {
        System.out.println(name + " says: \"" + dialogue + "\"");
    }

    @Override
    public String toString() {
        return super.toString() + ", friendlyDialogue='" + dialogue + "'";
    }
}
