public class Mage extends PlayerCharacter{
    private int intelligence;
    private int spellPower;

    public Mage(String name, int level, int healthPoints, int mana, int intelligence, int spellPower) {
        super(name, level, healthPoints, mana);
        this.intelligence = intelligence;
        this.spellPower = spellPower;
    }


    @Override
    public void attack() {
        if (mana >= 10) {
            System.out.println(name + " casts a fireball! (Spell Power: " + spellPower + ")");
            mana -= 10;
        } else {
            System.out.println(name + " does not have enough mana to cast spells!");
        }
    }

    @Override
    public void defend() {
        System.out.println(name + " conjures a magical barrier!");
    }

    @Override
    public String toString() {
        return super.toString() +
                ", intelligence=" + intelligence +
                ", spellPower=" + spellPower;
    }
}
