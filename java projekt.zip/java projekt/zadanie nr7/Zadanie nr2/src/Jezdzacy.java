public interface Jezdzacy {
    int getPredkosc();
    void setPredkosc(int predkosc);
    int getMaxPredkosc();
    void setMaxPredkosc(int maxPredkosc);
    // Zmiana prędkości
    boolean zwiekszPredkosc(int ile);
    boolean zmniejszPredkosc(int ile);
    private String vehicleInfo() {
        return getPredkosc() + " " + getMaxPredkosc();
    }
    default String info() {
        return "Statystyki pojazdu: " + vehicleInfo();
    }
}
