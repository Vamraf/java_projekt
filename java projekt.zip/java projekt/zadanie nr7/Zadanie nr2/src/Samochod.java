public class Samochod implements Jezdzacy{

    private int predkosc;
    private int maxPredkosc;

    public Samochod(int maxPredkosc) {
        this.maxPredkosc = maxPredkosc;
        this.predkosc = 0;
    }

    // Gettery / settery
    @Override
    public int getPredkosc() {
        return predkosc;
    }

    @Override
    public void setPredkosc(int predkosc) {
        if (predkosc <= maxPredkosc && predkosc >= 0)
            this.predkosc = predkosc;
    }

    @Override
    public int getMaxPredkosc() {
        return maxPredkosc;
    }

    @Override
    public void setMaxPredkosc(int maxPredkosc) {
        if (maxPredkosc > 0)
            this.maxPredkosc = maxPredkosc;
    }
    @Override
    public boolean zwiekszPredkosc(int ile) {
        if (predkosc + ile <= maxPredkosc) {
            predkosc += ile;
            return true;
        }
        return false;
    }

    @Override
    public boolean zmniejszPredkosc(int ile) {
        if (predkosc - ile >= 0) {
            predkosc -= ile;
            return true;
        }
        return false;
    }
    private String vehicleInfo() {
        return predkosc + " " + maxPredkosc;
    }

    // Info() wykorzystujące prywatną metodę
    @Override
    public String info() {
        return "Samochod: Statystyki pojazdu: " + vehicleInfo();
    }
}