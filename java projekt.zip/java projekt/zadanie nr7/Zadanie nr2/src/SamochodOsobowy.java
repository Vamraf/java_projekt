public class SamochodOsobowy extends Samochod {

    public SamochodOsobowy(int maxPredkosc) {
        super(maxPredkosc);
    }

    @Override
    public String info() {
        return "Samochod osobowy: " + super.info();
    }
}
