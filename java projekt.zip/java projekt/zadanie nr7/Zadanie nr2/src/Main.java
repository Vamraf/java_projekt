void main() {
    SamochodOsobowy S = new SamochodOsobowy(340);
    S.zwiekszPredkosc(100);
    S.zwiekszPredkosc(50);
    S.zmniejszPredkosc(20);
    System.out.println(S.info());
}
