public class Ptak extends Zwierze implements Latajacy {
    private int wysokoscLotu;
    private TypGniazdowania typGniazdowania;

    public Ptak(String gatunek, int wiek, int wysokoscLotu, TypGniazdowania typGniazdowania) {
        super(gatunek, wiek);
        this.wysokoscLotu = wysokoscLotu;
        this.typGniazdowania = typGniazdowania;
    }

    @Override
    public void dajGlos() {
        System.out.println("Ptak " + gatunek + " mówi: ćwir ćwir!");
    }

    @Override
    public void lecWyzej() {
        wysokoscLotu++;
        System.out.println("Ptak wznosi się wyżej. Aktualna wysokość: " + wysokoscLotu);
    }

    @Override
    public void lecNizej() {
        wysokoscLotu--;
        System.out.println("Ptak opada niżej. Aktualna wysokość: " + wysokoscLotu);
    }

    @Override
    public String toString() {
        return super.toString() + " " + wysokoscLotu + " " + typGniazdowania;
    }
}
