public enum RodzajDiety {
    MIESOZERNY,
    ROZLINOZERNY,
    WSZYSTKOZERNY
}
