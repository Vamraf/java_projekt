public class  Pojazd extends Maszyna implements Jezdzacy {
    protected int predkosc;

    public Pojazd(String nazwa, String numerSeryjny, int predkosc) {
        super(nazwa, numerSeryjny);
        this.predkosc = predkosc;
    }

    @Override
    public void przyspiesz() {
        predkosc++;
        System.out.println("Pojazd przyspiesza. Aktualna prędkość: " + predkosc);
    }

    @Override
    public void zwolnij() {
        predkosc--;
        System.out.println("Pojazd zwalnia. Aktualna prędkość: " + predkosc);
    }

    @Override
    public String toString() {
        return super.toString() + " " + predkosc;
    }
}
