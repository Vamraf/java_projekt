public abstract class Zwierze {
    protected String gatunek;
    protected int wiek;

    public Zwierze(String gatunek, int wiek) {
        this.gatunek = gatunek;
        this.wiek = wiek;
    }

    public abstract void dajGlos();

    @Override
    public String toString() {
        return gatunek + " " + wiek;
    }
}
