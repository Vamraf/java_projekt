public abstract class Maszyna {
    protected String nazwa;
    protected String numerSeryjny;

    public Maszyna(String nazwa, String numerSeryjny) {
        this.nazwa = nazwa;
        this.numerSeryjny = numerSeryjny;
    }

    @Override
    public String toString() {
        return nazwa + " " + numerSeryjny;
    }
}
