void main() {
    Samochod s = new Samochod("Samochod1", "123", 50, Marka.BMW);
    Samolot samolot = new Samolot("Samolot1", "321", 600, 10000);
    Ptak p = new Ptak("Wróbel", 2, 10, TypGniazdowania.GNIAZDOWNIK);
    Delfin d = new Delfin("Delfin", 5, RodzajDiety.MIESOZERNY, 50);
    System.out.println(s);
    System.out.println(samolot);
    System.out.println(p);
    System.out.println(d);
    System.out.println("Metody interfejsów");
    s.przyspiesz();
    s.przyspiesz();
    s.zwolnij();
    samolot.lecWyzej();
    samolot.lecNizej();
    p.lecWyzej();
    p.lecNizej();
    System.out.println("Głosy zwierząt");
    p.dajGlos();
    d.dajGlos();
}
