public class Samolot extends Pojazd implements Latajacy {
    private int wysokoscLotu;

    public Samolot(String nazwa, String numerSeryjny, int predkosc, int wysokoscLotu) {
        super(nazwa, numerSeryjny, predkosc);
        this.wysokoscLotu = wysokoscLotu;
    }

    @Override
    public void lecWyzej() {
        wysokoscLotu++;
        System.out.println("Samolot wznosi się. Wysokość: " + wysokoscLotu);
    }

    @Override
    public void lecNizej() {
        wysokoscLotu--;
        System.out.println("Samolot opada. Wysokość: " + wysokoscLotu);
    }

    @Override
    public String toString() {
        return super.toString() + " " + wysokoscLotu;
    }
}
