public class Delfin extends Ssak {
    private int glebokoscZanurzenia;

    public Delfin(String gatunek, int wiek, RodzajDiety rodzajDiety, int glebokoscZanurzenia) {
        super(gatunek, wiek, rodzajDiety);
        this.glebokoscZanurzenia = glebokoscZanurzenia;
    }

    @Override
    public void dajGlos() {
        System.out.println("Delfin " + gatunek + " wydaje dźwięk: klik klik!");
    }

    @Override
    public String toString() {
        return super.toString() + " " + glebokoscZanurzenia;
    }
}
