public interface Jezdzacy {
    void przyspiesz();
    void zwolnij();
}
