public enum Marka {
    BMW,
    AUDI,
    TOYOTA,
    HONDA
}
