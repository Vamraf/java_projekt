public abstract class Ssak extends Zwierze {
    protected RodzajDiety rodzajDiety;

    public Ssak(String gatunek, int wiek, RodzajDiety rodzajDiety) {
        super(gatunek, wiek);
        this.rodzajDiety = rodzajDiety;
    }

    @Override
    public String toString() {
        return super.toString() + " " + rodzajDiety;
    }
}
