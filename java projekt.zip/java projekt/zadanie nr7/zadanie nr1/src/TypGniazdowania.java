public enum TypGniazdowania {
    GNIAZDOWNIK,
    ZAGNIAZDOWNIK
}
