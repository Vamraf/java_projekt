public class Samochod extends Pojazd {
    private Marka marka;

    public Samochod(String nazwa, String numerSeryjny, int predkosc, Marka marka) {
        super(nazwa, numerSeryjny, predkosc);
        this.marka = marka;
    }
    @Override
    public String toString() {
        return super.toString() + " " + marka;
    }
}
