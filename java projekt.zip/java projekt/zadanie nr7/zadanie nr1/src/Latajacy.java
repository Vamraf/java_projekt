public interface Latajacy {
    void lecWyzej();
    void lecNizej();
}
